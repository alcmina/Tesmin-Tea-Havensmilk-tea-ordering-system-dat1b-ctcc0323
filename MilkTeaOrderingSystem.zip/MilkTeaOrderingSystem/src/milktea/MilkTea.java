package milktea;

import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MilkTea extends javax.swing.JFrame {

    public MilkTea() {
        initComponents();
    }
    
    DefaultTableModel model;
    String item;
    String size;
    int price;
    
    Connection con;
    PreparedStatement pst;
    PreparedStatement pst1;
    PreparedStatement pst2;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        bttnClear = new javax.swing.JButton();
        spinQty = new javax.swing.JSpinner();
        txtPay = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtBal = new javax.swing.JTextField();
        bttnAdd = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        radSmall = new javax.swing.JRadioButton();
        radMedium = new javax.swing.JRadioButton();
        radLarge = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        txtTotal = new javax.swing.JTextField();
        bttnRemove = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        boxBrown = new javax.swing.JCheckBox();
        boxHok = new javax.swing.JCheckBox();
        jLabel7 = new javax.swing.JLabel();
        boxChoco = new javax.swing.JCheckBox();
        boxLy = new javax.swing.JCheckBox();
        boxMat = new javax.swing.JCheckBox();
        boxOki = new javax.swing.JCheckBox();
        boxOre = new javax.swing.JCheckBox();
        boxThai = new javax.swing.JCheckBox();
        boxWin = new javax.swing.JCheckBox();
        boxTar = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(153, 153, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel3.setForeground(new java.awt.Color(255, 255, 153));

        jLabel3.setFont(new java.awt.Font("Courier New", 1, 16)); // NOI18N
        jLabel3.setText("QTY");

        bttnClear.setBackground(new java.awt.Color(164, 125, 209));
        bttnClear.setFont(new java.awt.Font("Courier New", 1, 16)); // NOI18N
        bttnClear.setText("CLEAR");
        bttnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnClearActionPerformed(evt);
            }
        });

        spinQty.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N

        txtPay.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Courier New", 1, 16)); // NOI18N
        jLabel4.setText("PAYMENT:");

        jLabel5.setFont(new java.awt.Font("Courier New", 1, 16)); // NOI18N
        jLabel5.setText("CHANGE:");

        txtBal.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        txtBal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBalActionPerformed(evt);
            }
        });

        bttnAdd.setBackground(new java.awt.Color(164, 125, 209));
        bttnAdd.setFont(new java.awt.Font("Courier New", 1, 16)); // NOI18N
        bttnAdd.setText("ADD");
        bttnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnAddActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(164, 125, 209));
        jButton2.setFont(new java.awt.Font("Courier New", 1, 16)); // NOI18N
        jButton2.setText("DONE");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Courier New", 1, 16)); // NOI18N
        jLabel6.setText("TOTAL:");

        jPanel1.setBackground(new java.awt.Color(253, 244, 220));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("Courier New", 1, 24)); // NOI18N
        jLabel1.setText("TESMIN MILKTEA HAVENS ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(198, 198, 198))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1))
        );

        jPanel2.setBackground(new java.awt.Color(253, 244, 220));
        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        radSmall.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        radSmall.setText("SMALL");
        radSmall.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        radSmall.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radSmallActionPerformed(evt);
            }
        });

        radMedium.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        radMedium.setText("MEDIUM");
        radMedium.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        radMedium.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radMediumActionPerformed(evt);
            }
        });

        radLarge.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        radLarge.setText("LARGE");
        radLarge.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        radLarge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radLargeActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Courier New", 1, 16)); // NOI18N
        jLabel2.setText("CUP SIZE:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(radMedium)
                        .addComponent(radSmall)
                        .addComponent(radLarge))
                    .addComponent(jLabel2))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(radSmall)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(radMedium)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(radLarge)
                .addContainerGap(7, Short.MAX_VALUE))
        );

        jTable1.setBackground(new java.awt.Color(253, 244, 220));
        jTable1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTable1.setFont(new java.awt.Font("Courier New", 0, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item:", "Size:", "Price:", "Qty:", "Total:"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        txtTotal.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N

        bttnRemove.setBackground(new java.awt.Color(164, 125, 209));
        bttnRemove.setFont(new java.awt.Font("Courier New", 1, 16)); // NOI18N
        bttnRemove.setText("REMOVE");
        bttnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnRemoveActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(253, 244, 220));
        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        boxBrown.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        boxBrown.setText("BROWN SUGAR");
        boxBrown.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        boxBrown.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxBrownActionPerformed(evt);
            }
        });

        boxHok.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        boxHok.setText("HOKKAIDO");
        boxHok.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        boxHok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxHokActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Courier New", 1, 16)); // NOI18N
        jLabel7.setText("MILKTEA FLAVORS:");

        boxChoco.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        boxChoco.setText("CHOCOLATE");
        boxChoco.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        boxChoco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxChocoActionPerformed(evt);
            }
        });

        boxLy.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        boxLy.setText("LYCHEE");
        boxLy.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        boxLy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxLyActionPerformed(evt);
            }
        });

        boxMat.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        boxMat.setText("MATCHA");
        boxMat.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        boxMat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxMatActionPerformed(evt);
            }
        });

        boxOki.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        boxOki.setText("OKINAWA");
        boxOki.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        boxOki.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxOkiActionPerformed(evt);
            }
        });

        boxOre.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        boxOre.setText("OREO MILKTEA ");
        boxOre.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        boxOre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxOreActionPerformed(evt);
            }
        });

        boxThai.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        boxThai.setText("THAI MILKTEA");
        boxThai.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        boxThai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxThaiActionPerformed(evt);
            }
        });

        boxWin.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        boxWin.setText("WINTERMELON ");
        boxWin.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        boxWin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxWinActionPerformed(evt);
            }
        });

        boxTar.setFont(new java.awt.Font("Courier New", 1, 14)); // NOI18N
        boxTar.setText("TARO");
        boxTar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        boxTar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxTarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(boxChoco)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(boxLy, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(boxOre)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(boxThai)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(boxBrown)
                        .addGap(28, 28, 28)
                        .addComponent(boxHok)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(boxOki)
                        .addGap(27, 27, 27)
                        .addComponent(boxTar)
                        .addGap(30, 30, 30))))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(86, 86, 86)
                .addComponent(boxMat, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(boxWin)
                .addGap(72, 72, 72))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boxBrown)
                    .addComponent(boxHok)
                    .addComponent(boxOki)
                    .addComponent(boxTar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boxChoco)
                    .addComponent(boxLy)
                    .addComponent(boxOre)
                    .addComponent(boxThai))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(boxMat)
                    .addComponent(boxWin))
                .addContainerGap(11, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(13, 13, 13)
                                        .addComponent(jLabel3))
                                    .addComponent(spinQty, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bttnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jScrollPane1)
                                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(bttnRemove))
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel4)
                                        .addComponent(jLabel5)
                                        .addComponent(txtBal)
                                        .addComponent(txtPay, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel6))
                                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(6, 6, 6))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(bttnClear, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addGap(4, 4, 4)
                        .addComponent(spinQty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(7, 7, 7)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPay, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtBal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(bttnAdd)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(bttnRemove))
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(bttnClear)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void radLargeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radLargeActionPerformed
        if (radLarge.isSelected()){
            radSmall.setSelected(false);
            radMedium.setSelected(false);
        }
    }//GEN-LAST:event_radLargeActionPerformed

    private void txtBalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBalActionPerformed

    private void bttnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnAddActionPerformed
        // TODO add your handling code here:
      if(radSmall.isSelected() == true){
          size = "Small";
          price = 65;
      }
      else if(radMedium.isSelected() == true){
          size = "Medium";
          price = 85;
      }
      else if(radLarge.isSelected() == true){
          size = "Large";
          price = 100;
      }
      
      if(boxBrown.isSelected() == true){
          item = "BROWNN SUGAR MILKTEA ";
      }
      else if(boxChoco.isSelected() == true){
          item = "CHOCOLATE MILKTEA ";
      }
      else if(boxHok.isSelected() == true){
          item = "HOKKAIDO MILKTEA  ";
      }
	else if(boxLy.isSelected() == true){
          item = "LYCHEE MILKTEA ";
      }
	else if(boxMat.isSelected() == true){
          item = "MATCHA MILKTEA ";
      }
	else if(boxOki.isSelected() == true){
          item = "OKINAWA";
      }
	else if(boxOre.isSelected() == true){
          item = "OREO MILKTEA ";
      }
	else if(boxTar.isSelected() == true){
          item = "TARO MILKTEA";
      }
	else if(boxThai.isSelected() == true){
          item = "THAI MILKTEA";
      }
        else if(boxWin.isSelected() == true){
         item = "WINTERMELON";
      }

      
      int qty = Integer.parseInt(spinQty.getValue().toString());
      int total = qty * price;
      
      model = (DefaultTableModel)jTable1.getModel();
      
      model.addRow(new Object[]{
          item,
          size,
          price,
          qty,
          total,
      });
      
      int sum = 0;
      for(int a=0; a<jTable1.getRowCount(); a++){
          sum = sum + Integer.parseInt(jTable1.getValueAt(a,4).toString());
      }
       txtTotal.setText(Integer.toString(sum));
    }//GEN-LAST:event_bttnAddActionPerformed

    public void sales(){
        int lastid = 0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/milktea","root","");
            
            String total = txtTotal.getText();
            String pay = txtPay.getText();
            String balance = txtBal.getText();
            
            String query = "insert into sales(subtotal,pay,balance)values(?,?,?)";
            pst = con.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
            pst.setString(1, total);
            pst.setString(2, pay);
            pst.setString(3, balance);
            pst.executeUpdate();
            
            ResultSet rs = pst.getGeneratedKeys();
            
            if(rs.next()){
                lastid = rs.getInt(1);
            }
                
            int row =jTable1.getRowCount();
            
            String query1 = "insert into sales_product(sales_id,productname,size,price,qty,total)values(?,?,?,?,?,?)";
            pst1 = con.prepareStatement(query1);
            
            String prodname = "";
            String size ="";
            int price;
            int qty;
            int tot =0;
            
            for(int i=0; i<jTable1.getRowCount(); i++){
               prodname = (String)jTable1.getValueAt(i, 0);
               size = (String)jTable1.getValueAt(i,1);
               price = (int)jTable1.getValueAt(i, 2);
               qty = (int)jTable1.getValueAt(i, 3);
               tot = (int)jTable1.getValueAt(i, 4);
                
               pst1.setInt(1, lastid);
               pst1.setString(2, prodname);
               pst1.setString(3, size);
               pst1.setInt(4, price);
               pst1.setInt(5, qty);
               pst1.setInt(6, tot);
               pst1.executeUpdate();
                   
            }
        
            JOptionPane.showMessageDialog(this, "Sales Complete");
     
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MilkTea.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MilkTea.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void bttnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnRemoveActionPerformed
        // TODO add your handling code here:
        
        model.removeRow(jTable1.getSelectedRow());
        {
        int sum = 0;
        for (int a=0; a<jTable1.getRowCount(); a++){
          sum = sum + Integer.parseInt(jTable1.getValueAt(a,4).toString());
      }
       txtTotal.setText(Integer.toString(sum));
        }   
    }//GEN-LAST:event_bttnRemoveActionPerformed

    private void radSmallActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radSmallActionPerformed
        // TODO add your handling code here:
         if (radSmall.isSelected())
            radMedium.setSelected(false);
            radLarge.setSelected(false);
    }//GEN-LAST:event_radSmallActionPerformed

    private void radMediumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radMediumActionPerformed
        // TODO add your handling code here:
         if (radMedium.isSelected())
            radSmall.setSelected(false);
            radLarge.setSelected(false);
    }//GEN-LAST:event_radMediumActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        int total = Integer .parseInt(txtTotal.getText());
        int pay = Integer .parseInt(txtPay.getText());
        
        int bal = pay - total;
        txtBal.setText(String.valueOf(bal));
        
        sales();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void bttnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnClearActionPerformed
      txtTotal.setText("");
      txtPay.setText("");
      txtBal.setText("");
      radSmall.setSelected(false);
      radMedium.setSelected(false);
      radLarge.setSelected(false);
      boxBrown.setSelected(false);
      boxChoco.setSelected(false);
      boxHok.setSelected(false);
      boxLy.setSelected(false);
      boxMat.setSelected(false);
      boxOki.setSelected(false);
      boxOre.setSelected(false);
      boxTar.setSelected(false);
      boxThai.setSelected(false);
      boxWin.setSelected(false);
      model.setRowCount(0);
    }//GEN-LAST:event_bttnClearActionPerformed

    private void boxOreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxOreActionPerformed
    if(boxOre.isSelected())
        boxBrown.setSelected(false);
        boxChoco.setSelected(false);
        boxHok.setSelected(false);
        boxLy.setSelected(false);
        boxMat.setSelected(false);
        boxOki.setSelected(false);
        boxTar.setSelected(false);
        boxThai.setSelected(false);
        boxWin.setSelected(false);
    }//GEN-LAST:event_boxOreActionPerformed

    private void boxBrownActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxBrownActionPerformed
    if(boxBrown.isSelected())
        boxChoco.setSelected(false);
        boxHok.setSelected(false);
        boxLy.setSelected(false);
        boxMat.setSelected(false);
        boxOki.setSelected(false);
        boxOre.setSelected(false);
        boxTar.setSelected(false);
        boxThai.setSelected(false);
        boxWin.setSelected(false);
    }//GEN-LAST:event_boxBrownActionPerformed

    private void boxChocoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxChocoActionPerformed
    if(boxChoco.isSelected())
        boxBrown.setSelected(false);
        boxHok.setSelected(false);
        boxLy.setSelected(false);
        boxMat.setSelected(false);
        boxOki.setSelected(false);
        boxOre.setSelected(false);
        boxTar.setSelected(false);
        boxThai.setSelected(false);
        boxWin.setSelected(false);
    }//GEN-LAST:event_boxChocoActionPerformed

    private void boxHokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxHokActionPerformed
    if(boxHok.isSelected())
        boxBrown.setSelected(false);
        boxChoco.setSelected(false);
        boxLy.setSelected(false);
        boxMat.setSelected(false);
        boxOki.setSelected(false);
        boxOre.setSelected(false);
        boxTar.setSelected(false);
        boxThai.setSelected(false);
        boxWin.setSelected(false);
    }//GEN-LAST:event_boxHokActionPerformed

    private void boxLyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxLyActionPerformed
    if(boxLy.isSelected())
        boxBrown.setSelected(false);
        boxChoco.setSelected(false);
        boxHok.setSelected(false);
        boxMat.setSelected(false);
        boxOki.setSelected(false);
        boxOre.setSelected(false);
        boxTar.setSelected(false);
        boxThai.setSelected(false);
        boxWin.setSelected(false);
    }//GEN-LAST:event_boxLyActionPerformed

    private void boxMatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxMatActionPerformed
    if(boxMat.isSelected())
        boxBrown.setSelected(false);
        boxChoco.setSelected(false);
        boxHok.setSelected(false);
        boxLy.setSelected(false);
        boxOki.setSelected(false);
        boxOre.setSelected(false);
        boxTar.setSelected(false);
        boxThai.setSelected(false);
        boxWin.setSelected(false);
    }//GEN-LAST:event_boxMatActionPerformed

    private void boxOkiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxOkiActionPerformed
    if(boxOki.isSelected())
        boxBrown.setSelected(false);
        boxChoco.setSelected(false);
        boxHok.setSelected(false);
        boxLy.setSelected(false);
        boxMat.setSelected(false);
        boxOre.setSelected(false);
        boxTar.setSelected(false);
        boxThai.setSelected(false);
        boxWin.setSelected(false);
    }//GEN-LAST:event_boxOkiActionPerformed

    private void boxWinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxWinActionPerformed
    if(boxWin.isSelected())
        boxBrown.setSelected(false);
        boxChoco.setSelected(false);
        boxHok.setSelected(false);
        boxLy.setSelected(false);
        boxMat.setSelected(false);
        boxOki.setSelected(false);
        boxOre.setSelected(false);
        boxTar.setSelected(false);
        boxThai.setSelected(false);
    }//GEN-LAST:event_boxWinActionPerformed

    private void boxTarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxTarActionPerformed
    if(boxTar.isSelected())
        boxBrown.setSelected(false);
        boxChoco.setSelected(false);
        boxHok.setSelected(false);
        boxLy.setSelected(false);
        boxMat.setSelected(false);
        boxOki.setSelected(false);
        boxOre.setSelected(false);
        boxThai.setSelected(false);
        boxWin.setSelected(false);
    }//GEN-LAST:event_boxTarActionPerformed

    private void boxThaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxThaiActionPerformed
    if(boxThai.isSelected())
        boxBrown.setSelected(false);
        boxChoco.setSelected(false);
        boxHok.setSelected(false);
        boxLy.setSelected(false);
        boxMat.setSelected(false);
        boxOki.setSelected(false);
        boxOre.setSelected(false);
        boxTar.setSelected(false);
        boxThai.setSelected(false);
        boxWin.setSelected(false);
    }//GEN-LAST:event_boxThaiActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MilkTea.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MilkTea.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MilkTea.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MilkTea.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new MilkTea().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox boxBrown;
    private javax.swing.JCheckBox boxChoco;
    private javax.swing.JCheckBox boxHok;
    private javax.swing.JCheckBox boxLy;
    private javax.swing.JCheckBox boxMat;
    private javax.swing.JCheckBox boxOki;
    private javax.swing.JCheckBox boxOre;
    private javax.swing.JCheckBox boxTar;
    private javax.swing.JCheckBox boxThai;
    private javax.swing.JCheckBox boxWin;
    private javax.swing.JButton bttnAdd;
    private javax.swing.JButton bttnClear;
    private javax.swing.JButton bttnRemove;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JRadioButton radLarge;
    private javax.swing.JRadioButton radMedium;
    private javax.swing.JRadioButton radSmall;
    private javax.swing.JSpinner spinQty;
    private javax.swing.JTextField txtBal;
    private javax.swing.JTextField txtPay;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables

    private static class milktea {

        public milktea() {
        }
    }
}